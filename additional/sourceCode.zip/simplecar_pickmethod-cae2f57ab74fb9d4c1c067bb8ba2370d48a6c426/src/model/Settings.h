#ifndef SETTINGS_H
#define SETTINGS_H

#include <string>

using namespace std;

namespace car {
enum PickEnum{
	PickBasic 	= 0, // the basic approach, from back to front
	PickUC		= 1, // according to #(uc) generated in last round. NOTE: mUC is not considered.
	PickI		= 2, // always pick the initial state(s).
    PickSAT     = 3, // according to #(SAT) in the last round. == how many children it generated within the last try.
    PickDeep    = 4, // according to the deepest level.
    PickDegree  = 5, // how many children it had generated **within the whole run**.
	};
struct Settings {
    bool debug = false;
    bool forward = false;
    bool backward = false;
    bool bmc = false;
    int bmc_k = -1;
    bool end = false;
    int Branching = 0;
    bool skip_refer = false;
    bool witness = false;
    int seed = 0;
    int verbosity = 0;
    bool internalSignals = false;
    string aigFilePath;
    string outputDir;
    PickEnum pickMethod = PickBasic;
};

} // namespace car


#endif